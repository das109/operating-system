//2017310367, Jeong dasol


#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched/signal.h>
#include <linux/mm.h>

#define PSS_SHIFT 12

static int procinfo_proc_show(struct seq_file *m, void *v)
{
	struct task_struct *p;
	int nr_process = 0;
	
	seq_printf(m, "%-5s %-15s %-10s %-10s %-10s %-10s\n", "PID", "Process name", "VSS", "RSS", "PSS", "USS");

	/////////// CODE EXAMPLE
	for_each_process(p) // Traverse all processes
	{	
		struct vm_area_struct *vma;
		unsigned long vss = 0;
                unsigned long pss = 0;
                unsigned long rss = 0;
                unsigned long uss = 0;
				
				

		if (p->mm != NULL) { 
			for (vma = p->mm->mmap; vma; vma = vma->vm_next) {
	             	                
				struct mem_size_stats mss;
				struct mem_size_stats *ptr;

	                	memset(&mss, 0, sizeof(mss));
				smap_gather_stats(vma, &mss);
			
				ptr = &mss;

				vss = vss + (vma->vm_end - vma->vm_start);
				rss = rss + (ptr->resident);
				pss = pss + (ptr->pss >> PSS_SHIFT);
				uss = uss + (ptr->private_dirty + ptr->private_clean);

			}
		}
		nr_process += 1;
		
		
		
	 
                seq_printf(m, "%-5u %-15s %-10lu %-10lu %-10lu %-10lu\n", p->pid, p->comm, vss, rss, pss, uss);


	}
	seq_printf(m, "number of process: %d\n", nr_process);	// print number of process
	/////////////////////////

	return 0;
}

static int __init procrank_init(void)
{
	proc_create_single("procrank", 0, NULL, procinfo_proc_show); // create proc file
   	printk("init procrank ID:2017310367\n");
	return 0;
}

static void __exit procrank_exit(void)
{
	remove_proc_entry("procrank", NULL);	// delete proc file
	printk("exit procrank ID:2017310367\n");
}

module_init(procrank_init);
module_exit(procrank_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("procrank module");
MODULE_AUTHOR("[Jeong Dasol]");


