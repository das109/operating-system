#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

int main(int argc, char **argv) 
{

    struct stat sb;
    DIR            *dir_info;
    struct dirent  *dir_entry;    

    int     count;
    char filename[1024];
    int     idx;
    int flag = 0;
    int c;
   

    while ((c = getopt (argc, argv, "l")) != -1) {
	switch (c) {
	case 'l':
		flag = 1;
		break;
	default:
		printf("what?");
	}
    }
    dir_info = opendir(argv[optind]);              // 현재 디렉토리를 열기
   if ( NULL != dir_info)
   {
      while( dir_entry   = readdir( dir_info))
      {
  
	
	printf( "%s\n", dir_entry->d_name);
	if (strcmp (dir_entry->d_name, ".")==0) {continue;}
	if (strcmp (dir_entry->d_name, "..")==0) {continue;}
	sprintf(filename,"%s/%s", argv[optind], dir_entry->d_name); 
	if (stat(filename, &sb) == -1) {continue;}
	if (flag) {
                printf("     I-node number:            %ld\n", (long) sb.st_ino);
                printf("     Mode:                     %lo (octal)\n", (unsigned long) sb.st_mode);
                printf("     Link count:               %ld\n", (long) sb.st_nlink);
                printf("     Ownership:                UID=%ld   GID=%ld\n", (long) sb.st_uid, (long) sb.st_gid);

                printf("     Preferred I/O block size: %ld bytes\n", (long) sb.st_blksize);
                printf("     File size:                %lld bytes\n", (long long) sb.st_size);
                printf("     Blocks allocated:         %lld\n", (long long) sb.st_blocks);

        	fprintf(stderr, "%s Directory Scan Error: %s\n", argv[optind], strerror(errno));
        
   		 }
		
	     }
closedir( dir_info);
	
}
    return 0;
}

